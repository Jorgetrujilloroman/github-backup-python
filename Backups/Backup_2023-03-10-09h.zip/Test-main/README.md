# Test
Test to made an python script


To install a SSH-Agentin windows: https://interworks.com/blog/2021/09/15/setting-up-ssh-agent-in-windows-for-passwordless-git-authentication/


To generate a GitHub token: https://devops.pingidentity.com/how-to/privateRepos/

SSH key GitHub:

-Generating: https://docs.github.com/en/authentication/connecting-to-github-with-ssh/generating-a-new-ssh-key-and-adding-it-to-the-ssh-agent
-Adding to your account: https://docs.github.com/en/authentication/connecting-to-github-with-ssh/adding-a-new-ssh-key-to-your-github-account
-Testing connection: https://docs.github.com/en/authentication/connecting-to-github-with-ssh/testing-your-ssh-connection

